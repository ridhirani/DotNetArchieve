﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Serialization_DSerialization
{
    [Serializable]
    class Tutorial
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
